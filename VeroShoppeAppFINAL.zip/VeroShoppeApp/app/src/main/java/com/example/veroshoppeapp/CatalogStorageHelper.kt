package com.example.veroshoppeapp

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import androidx.core.content.edit

object CatalogStorageHelper {
    private const val PREFS_NAME = "catalog_prefs"
    private const val CATALOG_ITEMS_KEY = "catalog_items"

    fun saveCatalogItems(context: Context, items: List<CatalogItem>) {
        val json = Gson().toJson(items)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit() {
                putString(CATALOG_ITEMS_KEY, json)
            }
    }

    fun getCatalogItems(context: Context): List<CatalogItem> {
        val json = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(CATALOG_ITEMS_KEY, null) ?: return emptyList()

        val type = object : TypeToken<List<CatalogItem>>() {}.type
        return Gson().fromJson(json, type) ?: emptyList()
    }
}