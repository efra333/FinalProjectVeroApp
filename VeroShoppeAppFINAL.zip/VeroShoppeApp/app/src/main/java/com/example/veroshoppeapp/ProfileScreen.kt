package com.example.veroshoppeapp

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil.compose.rememberImagePainter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import androidx.core.content.edit
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    navController: NavController,
    onNavigateToProfile: () -> Unit = {} // Default empty lambda
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var pronouns by remember { mutableStateOf("") }
    var profileImageUri by remember { mutableStateOf<Uri?>(null) }
    var showPronounsDialog by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }

    val pronounsOptions = listOf(
        "She/Her", "He/Him", "They/Them", "Other", "Prefer not to say"
    )

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            profileImageUri = it
            // Save locally
            saveProfilePictureUri(context, it.toString())
        }
    }

    // Load user data
    LaunchedEffect(Unit) {
        isLoading = true
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return@LaunchedEffect

        // Load from Firestore
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(userId)
            .get()
            .addOnSuccessListener { document ->
                name = document.getString("name") ?: ""
                lastName = document.getString("lastName") ?: ""
                isLoading = false
            }

        // Load pronouns from SharedPreferences
        pronouns = getSavedPronouns(context)

        // Load profile picture URI
        getSavedProfilePictureUri(context)?.let {
            profileImageUri = Uri.parse(it)
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("My Profile") }
            )
        },
        bottomBar = {
            BottomNavigationBar(
                navController = navController,
                onProfileClick = onNavigateToProfile
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Profile Picture Section
                Box(
                    contentAlignment = Alignment.BottomEnd
                ) {
                    val painter = if (profileImageUri != null) {
                        rememberImagePainter(profileImageUri)
                    } else {
                        painterResource(R.drawable.ic_profile_placeholder) // Add a placeholder drawable
                    }

                    Image(
                        painter = painter,
                        contentDescription = "Profile Picture",
                        modifier = Modifier
                            .size(120.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )

                    IconButton(
                        onClick = { imagePicker.launch("image/*") },
                        modifier = Modifier.offset(x = 10.dp, y = 10.dp)
                    ) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Change Profile Picture",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Name Section
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("First Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = lastName,
                    onValueChange = { lastName = it },
                    label = { Text("Last Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Pronouns Section
                OutlinedTextField(
                    value = pronouns,
                    onValueChange = {},
                    label = { Text("Preferred Pronouns") },
                    readOnly = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showPronounsDialog = true },
                    trailingIcon = {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Pronouns")
                    }
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Save Button
                Button(
                    onClick = {
                        saveProfile(context, name, lastName)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save Changes")
                }
            }
        }

        // Pronouns Selection Dialog
        if (showPronounsDialog) {
            AlertDialog(
                onDismissRequest = { showPronounsDialog = false },
                title = { Text("Select Pronouns") },
                text = {
                    Column {
                        pronounsOptions.forEach { option ->
                            RadioButtonItem(
                                text = option,
                                selected = pronouns == option,
                                onSelect = { pronouns = option }
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            savePronouns(context, pronouns)
                            showPronounsDialog = false
                        }
                    ) {
                        Text("OK")
                    }
                }
            )
        }
    }
}

@Composable
fun RadioButtonItem(text: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .padding(8.dp)
    ) {
        RadioButton(
            selected = selected,
            onClick = onSelect
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text)
    }
}

// Local storage functions
private fun saveProfile(context: Context, name: String, lastName: String) {
    val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

    FirebaseFirestore.getInstance()
        .collection("users")
        .document(userId)
        .update(
            mapOf(
                "name" to name,
                "lastName" to lastName
            )
        )
}

private fun savePronouns(context: Context, pronouns: String) {
    context.getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)
        .edit() {
            putString("pronouns", pronouns)
        }
}

private fun getSavedPronouns(context: Context): String {
    return context.getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)
        .getString("pronouns", "") ?: ""
}

private fun saveProfilePictureUri(context: Context, uri: String) {
    context.getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)
        .edit() {
            putString("profile_picture_uri", uri)
        }
}

private fun getSavedProfilePictureUri(context: Context): String? {
    return context.getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)
        .getString("profile_picture_uri", null)
}