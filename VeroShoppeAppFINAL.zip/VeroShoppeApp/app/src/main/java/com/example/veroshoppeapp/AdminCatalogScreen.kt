package com.example.veroshoppeapp

import android.content.Context
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.UUID

// Data class for CatalogItem


// Data class for Promotion
data class Promotion(
    val id: String,
    val description: String,
    val imageUrl: String,
    val timestamp: Long
)

// AdminCatalogScreen.kt
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminCatalogScreen(
    context: Context,
    navController: NavController,
    onNavigateToProfile: () -> Unit
) {
    var catalogItems by remember { mutableStateOf(listOf<CatalogItem>()) }
    var showAddDialog by remember { mutableStateOf(false) }
    var newItemName by remember { mutableStateOf("") }
    var newItemDesc by remember { mutableStateOf("") }
    var newItemImageUrl by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }
    val firestore = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()

    // Verificar autenticación
    LaunchedEffect(Unit) {
        Log.d("FirebaseAuth", "Usuario actual: ${auth.currentUser?.uid ?: "null"}")
    }

    // Cargar ítems del catálogo desde Firestore o SharedPreferences
    LaunchedEffect(Unit) {
        firestore.collection("catalog")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    feedbackMessage = "Error al cargar catálogo desde Firestore: ${e.message}"
                    Log.e("Firestore", "Error al cargar catálogo: ${e.message}")
                    // Cargar desde SharedPreferences como respaldo
                    catalogItems = CatalogStorageHelper.getCatalogItems(context)
                    return@addSnapshotListener
                }
                snapshot?.let {
                    catalogItems = it.documents.mapNotNull { doc ->
                        try {
                            CatalogItem(
                                id = doc.id,
                                name = doc.getString("name") ?: "",
                                description = doc.getString("description") ?: "",
                                imageUri = doc.getString("imageUrl")
                            )
                        } catch (e: Exception) {
                            Log.e("Firestore", "Error al parsear item: ${e.message}")
                            null
                        }
                    }
                    // Guardar en SharedPreferences
                    CatalogStorageHelper.saveCatalogItems(context, catalogItems)
                    Log.d("CatalogStorage", "Catálogo guardado localmente: ${catalogItems.size} ítems")
                }
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manage Catalog") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { navController.navigate("promotions") }) {
                        Icon(Icons.Default.Star, contentDescription = "Ofertas y Promociones")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                modifier = Modifier.padding(16.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Item")
            }
        },
        bottomBar = {
            BottomNavigationBar(
                navController = navController,
                onProfileClick = onNavigateToProfile
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            feedbackMessage?.let {
                Text(
                    text = it,
                    color = if (it.contains("exitosamente") || it.contains("correctamente")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
            }
            if (catalogItems.isEmpty()) {
                Text(
                    text = "No hay productos en el catálogo.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(16.dp)
                )
            } else {
                LazyColumn {
                    items(catalogItems) { item ->
                        CatalogItemCard(
                            item = item,
                            onDelete = {
                                firestore.collection("catalog").document(item.id).delete()
                                // Actualizar localmente
                                catalogItems = catalogItems.filter { it.id != item.id }
                                CatalogStorageHelper.saveCatalogItems(context, catalogItems)
                            }
                        )
                        Divider()
                    }
                }
            }
        }
    }

    // Add New Item Dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSaving) showAddDialog = false },
            title = { Text("Add New Catalog Item") },
            text = {
                Column {
                    OutlinedTextField(
                        value = newItemName,
                        onValueChange = { newItemName = it },
                        label = { Text("Item Name") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isSaving
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newItemDesc,
                        onValueChange = { newItemDesc = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isSaving
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newItemImageUrl,
                        onValueChange = { newItemImageUrl = it },
                        label = { Text("Image URL") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isSaving
                    )
                    feedbackMessage?.let {
                        Text(
                            text = it,
                            color = if (it.contains("exitosamente") || it.contains("correctamente")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = newItemName.isNotBlank() && newItemDesc.isNotBlank() && newItemImageUrl.isNotBlank() && !isSaving,
                    onClick = {
                        if (auth.currentUser == null) {
                            feedbackMessage = "Debes iniciar sesión para añadir productos."
                            showAddDialog = false
                            navController.navigate("login")
                            Log.w("FirebaseAuth", "Usuario no autenticado al intentar guardar producto")
                            return@Button
                        }
                        isSaving = true
                        feedbackMessage = null
                        Log.d("FirestoreSave", "Guardando producto: $newItemName")
                        val newItem = hashMapOf(
                            "name" to newItemName,
                            "description" to newItemDesc,
                            "imageUrl" to newItemImageUrl,
                            "timestamp" to System.currentTimeMillis()
                        )
                        firestore.collection("catalog")
                            .add(newItem)
                            .addOnSuccessListener { docRef ->
                                isSaving = false
                                val newCatalogItem = CatalogItem(
                                    id = docRef.id,
                                    name = newItemName,
                                    description = newItemDesc,
                                    imageUri = newItemImageUrl
                                )
                                catalogItems = catalogItems + newCatalogItem
                                CatalogStorageHelper.saveCatalogItems(context, catalogItems)
                                newItemName = ""
                                newItemDesc = ""
                                newItemImageUrl = ""
                                showAddDialog = false
                                feedbackMessage = "Producto añadido exitosamente."
                                Log.d("Firestore", "Producto guardado en Firestore con ID: ${docRef.id}")
                            }
                            .addOnFailureListener { e ->
                                isSaving = false
                                feedbackMessage = "Error al guardar en Firestore: ${e.message}"
                                Log.e("Firestore", "Error al guardar en Firestore: ${e.message}")
                            }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text("Add")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showAddDialog = false },
                    enabled = !isSaving
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun CatalogItemCard(item: CatalogItem, onDelete: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleLarge
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                }
            }
            item.imageUri?.let { uriString ->
                Image(
                    painter = rememberAsyncImagePainter(uriString),
                    contentDescription = item.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .padding(vertical = 8.dp),
                    contentScale = ContentScale.Crop
                )
            }
            Text(
                text = item.description,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

// PromotionsScreen.kt
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromotionsScreen(navController: NavController) {
    var description by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }
    var promotions by remember { mutableStateOf(listOf<Promotion>()) }
    val context = LocalContext.current
    val firestore = FirebaseFirestore.getInstance()
    val auth = FirebaseAuth.getInstance()

    // Verificar autenticación
    LaunchedEffect(Unit) {
        Log.d("FirebaseAuth", "Usuario actual: ${auth.currentUser?.uid ?: "null"}")
    }

    // Cargar promociones desde Firestore
    LaunchedEffect(Unit) {
        firestore.collection("promotions")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    feedbackMessage = "Error al cargar promociones: ${e.message}"
                    Log.e("Firestore", "Error al cargar promociones: ${e.message}")
                    return@addSnapshotListener
                }
                snapshot?.let {
                    promotions = it.documents.mapNotNull { doc ->
                        try {
                            Promotion(
                                id = doc.id,
                                description = doc.getString("description") ?: "",
                                imageUrl = doc.getString("imageUrl") ?: "",
                                timestamp = doc.getLong("timestamp") ?: 0
                            )
                        } catch (e: Exception) {
                            Log.e("Firestore", "Error al parsear promoción: ${e.message}")
                            null
                        }
                    }.sortedByDescending { it.timestamp }
                }
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ofertas y Promociones") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Descripción de la Promoción") },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isSaving
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = imageUrl,
                onValueChange = { imageUrl = it },
                label = { Text("Image URL") },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isSaving
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    if (auth.currentUser == null) {
                        feedbackMessage = "Debes iniciar sesión para añadir promociones."
                        navController.navigate("login")
                        Log.w("FirebaseAuth", "Usuario no autenticado al intentar guardar promoción")
                        return@Button
                    }
                    if (description.isNotBlank() && imageUrl.isNotBlank()) {
                        isSaving = true
                        feedbackMessage = null
                        Log.d("FirestoreSave", "Guardando promoción: $description")
                        val promotion = hashMapOf(
                            "description" to description,
                            "imageUrl" to imageUrl,
                            "timestamp" to System.currentTimeMillis()
                        )
                        firestore.collection("promotions")
                            .add(promotion)
                            .addOnSuccessListener {
                                isSaving = false
                                description = ""
                                imageUrl = ""
                                feedbackMessage = "Promoción añadida exitosamente."
                                Log.d("Firestore", "Promoción guardada en Firestore")
                            }
                            .addOnFailureListener { e ->
                                isSaving = false
                                feedbackMessage = "Error al guardar en Firestore: ${e.message}"
                                Log.e("Firestore", "Error al guardar en Firestore: ${e.message}")
                            }
                    } else {
                        feedbackMessage = "Por favor, completa todos los campos."
                        Log.w("FirestoreSave", "Campos incompletos: descripción=$description, imageUrl=$imageUrl")
                    }
                },
                enabled = !isSaving,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isSaving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Text("Guardar Promoción")
                }
            }
            feedbackMessage?.let {
                Text(
                    text = it,
                    color = if (it.contains("exitosamente") || it.contains("correctamente")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Promociones Guardadas",
                style = MaterialTheme.typography.titleMedium
            )
            if (promotions.isEmpty()) {
                Text(
                    text = "No hay promociones guardadas.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 8.dp)
                )
            } else {
                LazyColumn {
                    items(promotions) { promotion ->
                        PromotionCard(
                            promotion = promotion,
                            onDelete = {
                                firestore.collection("promotions").document(promotion.id).delete()
                            }
                        )
                        Divider()
                    }
                }
            }
        }
    }
}

@Composable
fun PromotionCard(promotion: Promotion, onDelete: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Promoción",
                    style = MaterialTheme.typography.titleLarge
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                }
            }
            Image(
                painter = rememberAsyncImagePainter(promotion.imageUrl),
                contentDescription = promotion.description,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .padding(vertical = 8.dp),
                contentScale = ContentScale.Crop
            )
            Text(
                text = promotion.description,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}