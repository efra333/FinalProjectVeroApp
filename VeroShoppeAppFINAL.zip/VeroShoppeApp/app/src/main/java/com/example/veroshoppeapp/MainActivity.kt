package com.example.veroshoppeapp

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

import com.example.veroshoppeapp.ui.theme.VeroShoppeAppTheme

class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VeroShoppeAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Llamamos a la función para configurar la navegación
                    VeroShoppeNavHost()
                }
            }
        }
    }
}


@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun VeroShoppeNavHost() {
    val navController = rememberNavController()
    var currentUserRole by remember { mutableStateOf("user") }
    val context = LocalContext.current

    // Fetch current user role
    LaunchedEffect(Unit) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return@LaunchedEffect
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(userId)
            .get()
            .addOnSuccessListener { document ->
                currentUserRole = document.getString("role") ?: "user"
            }
    }

    // Definir el NavHost y las rutas de las pantallas
    NavHost(navController = navController, startDestination = "login") {//Pantalla de inicio
        composable("login") {
            LoginScreen(
                onLoginSuccess = { navController.navigate("home") },
                onNavigateToRegister = { navController.navigate("register") }
            )
        }
        composable("register") {
            SignUpScreen(
                onSignUpSuccess = { navController.navigate("login") },
                onNavigateToLogin = { navController.navigate("login") }
            )
        }
        composable("home") {
            HomeScreen(
                navController = navController,
                onNavigateToProfile = {
                    if (currentUserRole == "admin") {
                        context.startActivity(Intent(context, EditUsersActivity::class.java))
                    } else {
                        navController.navigate("profile")
                    }
                }
            )
        }
        composable("appointments") {
            var currentUserRole by remember { mutableStateOf("user") }
            val context = LocalContext.current

            LaunchedEffect(Unit) {
                val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return@LaunchedEffect
                FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(userId)
                    .get()
                    .addOnSuccessListener { document ->
                        currentUserRole = document.getString("role") ?: "user"
                    }
            }

            AppointmentScreen(
                navController = navController,
                onNavigateToProfile = {
                    if (currentUserRole == "admin") {
                        context.startActivity(Intent(context, EditUsersActivity::class.java))
                    } else {
                        navController.navigate("profile")
                    }
                },
                context = context,
                isAdmin = currentUserRole == "admin"
            )
        }
        composable("catalog") {
            if (currentUserRole == "admin") {
                AdminCatalogScreen(
                    context = context,
                    navController = navController,
                    onNavigateToProfile = {
                        if (currentUserRole == "admin") {
                            context.startActivity(Intent(context, EditUsersActivity::class.java))
                        } else {
                            navController.navigate("profile")
                        }
                    }
                )
            } else {
                UserCatalogScreen(
                    context = context,
                    navController = navController,
                    onNavigateToProfile = { navController.navigate("profile") }
                )
            }
        }
        composable("profile") {
            ProfileScreen(
                navController = navController,
                onNavigateToProfile = {
                    if (currentUserRole == "admin") {
                        context.startActivity(Intent(context, EditUsersActivity::class.java))
                    } else {
                        navController.navigate("profile")
                    }
                    // Optional: Add refresh logic or scroll-to-top
                }
            )
        }
    }
}
/*@Composable
fun VeroShoppeNavHost() {
    val navController = rememberNavController()

    // Definir el NavHost y las rutas de las pantallas
    NavHost(navController = navController, startDestination = "login") {
        composable("login") {
            LoginScreen(
                onLoginSuccess = { navController.navigate("home") },  // Navegar al Home después de login exitoso
                onNavigateToRegister = { navController.navigate("register") }  // Navegar a la pantalla de registro
            )
        }
        composable("register") {
            SignUpScreen(
                onSignUpSuccess = { navController.navigate("login") },  // Navegar a la pantalla de login después de un registro exitoso
                onNavigateToLogin = { navController.navigate("login") }  // Navegar a la pantalla de login
            )
        }
        composable("home") {
            // Aquí puedes poner la pantalla principal después de login, como un Home o una pantalla de bienvenida

        }
    }
}
*/