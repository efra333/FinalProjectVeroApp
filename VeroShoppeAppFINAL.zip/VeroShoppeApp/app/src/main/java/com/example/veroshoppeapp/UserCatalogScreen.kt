package com.example.veroshoppeapp

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImagePainter
import coil.compose.rememberAsyncImagePainter
import com.google.firebase.firestore.FirebaseFirestore

// UserCatalogScreen.kt
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserCatalogScreen(
    context: Context,
    navController: NavController,
    onNavigateToProfile: () -> Unit
) {
    var catalogItems by remember { mutableStateOf(CatalogStorageHelper.getCatalogItems(context)) }
    var promotions by remember { mutableStateOf(listOf<Promotion>()) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }
    val firestore = FirebaseFirestore.getInstance()

    // Cargar ítems del catálogo desde Firestore
    LaunchedEffect(Unit) {
        firestore.collection("catalog")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    feedbackMessage = "Error al cargar catálogo: ${e.message}"
                    Log.e("Firestore", "Error al cargar catálogo: ${e.message}")
                    // Usar SharedPreferences como respaldo
                    catalogItems = CatalogStorageHelper.getCatalogItems(context)
                    return@addSnapshotListener
                }
                snapshot?.let {
                    catalogItems = it.documents.mapNotNull { doc ->
                        try {
                            CatalogItem(
                                id = doc.id,
                                name = doc.getString("name") ?: "",
                                description = doc.getString("description") ?: "",
                                imageUri = doc.getString("imageUrl")
                            )
                        } catch (e: Exception) {
                            Log.e("Firestore", "Error al parsear item: ${e.message}")
                            null
                        }
                    }
                    // Guardar en SharedPreferences
                    CatalogStorageHelper.saveCatalogItems(context, catalogItems)
                    Log.d("CatalogStorage", "Catálogo guardado localmente: ${catalogItems.size} ítems")
                }
            }
    }

    // Cargar promociones desde Firestore
    LaunchedEffect(Unit) {
        firestore.collection("promotions")
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    feedbackMessage = "Error al cargar promociones: ${e.message}"
                    Log.e("Firestore", "Error al cargar promociones: ${e.message}")
                    return@addSnapshotListener
                }
                snapshot?.let {
                    promotions = it.documents.mapNotNull { doc ->
                        try {
                            Promotion(
                                id = doc.id,
                                description = doc.getString("description") ?: "",
                                imageUrl = doc.getString("imageUrl") ?: "",
                                timestamp = doc.getLong("timestamp") ?: 0
                            )
                        } catch (e: Exception) {
                            Log.e("Firestore", "Error al parsear promoción: ${e.message}")
                            null
                        }
                    }.sortedByDescending { it.timestamp }
                }
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Our Services") }
            )
        },
        bottomBar = {
            BottomNavigationBar(
                navController = navController,
                onProfileClick = onNavigateToProfile
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            feedbackMessage?.let {
                Text(
                    text = it,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
            }
            if (catalogItems.isEmpty() && promotions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No catalog items or promotions available")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Sección de Catálogo
                    item {
                        Text(
                            text = "Catálogo",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                    if (catalogItems.isEmpty()) {
                        item {
                            Text(
                                text = "No hay productos en el catálogo.",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    } else {
                        items(catalogItems) { item ->
                            CatalogItemView(item = item)
                            Divider()
                        }
                    }

                    // Sección de Promociones
                    item {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Promociones",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                    if (promotions.isEmpty()) {
                        item {
                            Text(
                                text = "No hay promociones disponibles.",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    } else {
                        items(promotions) { promotion ->
                            PromotionView(promotion = promotion)
                            Divider()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CatalogItemView(item: CatalogItem) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            item.imageUri?.let { uriString ->
                Image(
                    painter = rememberAsyncImagePainter(
                        model = uriString,
                        onState = { state ->
                            if (state is AsyncImagePainter.State.Error) {
                                Log.e("ImageLoad", "Error al cargar imagen ${uriString}: ${state.result.throwable.message}")
                            }
                        }
                    ),
                    contentDescription = item.name,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .padding(vertical = 8.dp),
                    contentScale = ContentScale.Crop
                )
            }
            Text(
                text = item.description,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun PromotionView(promotion: Promotion) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = "Promoción",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            Image(
                painter = rememberAsyncImagePainter(
                    model = promotion.imageUrl,
                    onState = { state ->
                        if (state is AsyncImagePainter.State.Error) {
                            Log.e("ImageLoad", "Error al cargar imagen ${promotion.imageUrl}: ${state.result.throwable.message}")
                        }
                    }
                ),
                contentDescription = promotion.description,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .padding(vertical = 8.dp),
                contentScale = ContentScale.Crop
            )
            Text(
                text = promotion.description,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}