package com.example.veroshoppeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.rememberNavController
import com.example.veroshoppeapp.ui.theme.VeroShoppeAppTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class EditUsersActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VeroShoppeAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    UserManagementScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserManagementScreen() {
    var users by remember { mutableStateOf<List<UserData>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showEditDialog by remember { mutableStateOf(false) }
    var selectedUser by remember { mutableStateOf<UserData?>(null) }
    var tempRole by remember { mutableStateOf("user") }

    // Fetch all users from Firestore
    LaunchedEffect(Unit) {
        FirebaseFirestore.getInstance()
            .collection("users")
            .get()
            .addOnSuccessListener { documents ->
                users = documents.map { doc ->
                    UserData(
                        id = doc.id,
                        name = doc.getString("name") ?: "",
                        lastName = doc.getString("lastName") ?: "",
                        email = doc.getString("email") ?: "",
                        zodiacSign = doc.getString("zodiacSign") ?: "",
                        role = doc.getString("role") ?: "user"
                    )
                }
                isLoading = false
            }
            .addOnFailureListener {
                isLoading = false
            }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("User Management") },
                navigationIcon = {
                    IconButton(onClick = { /* Handle back navigation */ }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                items(users) { user ->
                    UserCard(
                        user = user,
                        onEditClick = {
                            selectedUser = user
                            tempRole = user.role
                            showEditDialog = true
                        },
                        onDeleteClick = {
                            // Handle delete user
                        }
                    )
                    Divider()
                }
            }
        }
    }

    // Edit User Dialog
    if (showEditDialog && selectedUser != null) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Edit User Role") },
            text = {
                Column {
                    Text("Name: ${selectedUser!!.name} ${selectedUser!!.lastName}")
                    Text("Email: ${selectedUser!!.email}")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Current Role: ${selectedUser!!.role}")
                    Spacer(modifier = Modifier.height(16.dp))

                    // Role selection
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        FilterChip(
                            selected = tempRole == "user",
                            onClick = { tempRole = "user" },
                            label = { Text("User") }
                        )
                        FilterChip(
                            selected = tempRole == "admin",
                            onClick = { tempRole = "admin" },
                            label = { Text("Admin") }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        // Update user role in Firestore
                        FirebaseFirestore.getInstance()
                            .collection("users")
                            .document(selectedUser!!.id)
                            .update("role", tempRole)
                            .addOnSuccessListener {
                                users = users.map { user ->
                                    if (user.id == selectedUser!!.id) {
                                        user.copy(role = tempRole)
                                    } else {
                                        user
                                    }
                                }
                                showEditDialog = false
                            }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showEditDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserCard(user: UserData, onEditClick: () -> Unit, onDeleteClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "${user.name} ${user.lastName}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = user.email,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Text(
                    text = user.role.uppercase(),
                    color = if (user.role == "admin") MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.labelLarge
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(onClick = onEditClick) {
                    Icon(Icons.Default.Edit, "Edit User")
                }
                IconButton(onClick = onDeleteClick) {
                    Icon(Icons.Default.Delete, "Delete User")
                }
            }
        }
    }
}

data class UserData(
    val id: String,
    val name: String,
    val lastName: String,
    val email: String,
    val zodiacSign: String,
    val role: String
)