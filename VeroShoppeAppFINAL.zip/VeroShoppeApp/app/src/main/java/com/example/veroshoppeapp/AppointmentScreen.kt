package com.example.veroshoppeapp

import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.annotation.RequiresApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.Gson
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.rememberDatePickerState
import androidx.navigation.NavController
import android.content.Intent

// AppointmentScreen.kt
@RequiresApi(Build.VERSION_CODES.O)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentScreen(
    navController: NavController,
    onNavigateToProfile: () -> Unit = {},
    context: Context = LocalContext.current,
    isAdmin: Boolean = false
) {
    var selectedDate by remember { mutableStateOf<LocalDate?>(null) }
    var selectedHour by remember { mutableStateOf("") }
    var showDatePicker by remember { mutableStateOf(false) }
    var showTimeDialog by remember { mutableStateOf(false) }
    var appointments by remember { mutableStateOf(AppointmentStorageHelper.getAppointments(context)) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var appointmentToDelete by remember { mutableStateOf<Appointment?>(null) }

    val currentUserEmail = FirebaseAuth.getInstance().currentUser?.email ?: ""

    // Hours available for appointments
    val availableHours = listOf(
        "09:00", "10:00", "11:00", "12:00",
        "13:00", "14:00", "15:00", "16:00", "17:00"
    )

    // Date picker
    if (showDatePicker) {
        val datePickerState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            selectedDate = Instant.ofEpochMilli(it)
                                .atZone(ZoneId.systemDefault())
                                .toLocalDate()
                        }
                        showDatePicker = false
                        showTimeDialog = true
                    }
                ) {
                    Text("OK")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isAdmin) "Manage Appointments" else "Book Appointment") }
            )
        },
        bottomBar = {
            BottomNavigationBar(
                navController = navController,
                onProfileClick = onNavigateToProfile
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Appointment creation section
            if (!isAdmin) {
                Button(
                    onClick = { showDatePicker = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("New Appointment")
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Time selection dialog
            if (showTimeDialog && selectedDate != null) {
                AlertDialog(
                    onDismissRequest = { showTimeDialog = false },
                    title = { Text("Select Time") },
                    text = {
                        Column {
                            availableHours.forEach { hour ->
                                RadioButtonItem(
                                    text = hour,
                                    selected = selectedHour == hour,
                                    onSelect = { selectedHour = hour }
                                )
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            enabled = selectedHour.isNotEmpty(),
                            onClick = {
                                val newAppointment = Appointment(
                                    date = selectedDate!!.toString(),
                                    hour = selectedHour,
                                    userEmail = currentUserEmail
                                )
                                appointments = appointments + newAppointment
                                AppointmentStorageHelper.saveAppointments(context, appointments)
                                selectedHour = ""
                                showTimeDialog = false
                            }
                        ) {
                            Text("Confirm")
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = { showTimeDialog = false }
                        ) {
                            Text("Cancel")
                        }
                    }
                )
            }

            // Appointments list
            Text(
                text = if (isAdmin) "All Appointments" else "My Appointments",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            if (appointments.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No appointments booked yet")
                }
            } else {
                LazyColumn {
                    items(
                        items = if (isAdmin) {
                            appointments
                        } else {
                            appointments.filter { it.userEmail == currentUserEmail }
                        },
                        key = { it.id }
                    ) { appointment ->
                        AppointmentItem(
                            appointment = appointment,
                            isAdmin = isAdmin,
                            onDelete = {
                                appointmentToDelete = appointment
                                showDeleteDialog = true
                            }
                        )
                        Divider()
                    }
                }
            }
        }
    }

    // Delete confirmation dialog
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Confirm Delete") },
            text = { Text("Are you sure you want to delete this appointment?") },
            confirmButton = {
                Button(
                    onClick = {
                        appointmentToDelete?.let {
                            AppointmentStorageHelper.deleteAppointment(context, it.id)
                            appointments = appointments.filter { item -> item.id != it.id }
                            showDeleteDialog = false
                        }
                    }
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AppointmentItem(
    appointment: Appointment,
    isAdmin: Boolean,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Date: ${appointment.date}",
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Text(
                        text = "Time: ${appointment.hour}",
                        style = MaterialTheme.typography.bodyLarge
                    )
                    if (isAdmin) {
                        Text(
                            text = "User: ${appointment.userEmail}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                if (isAdmin) {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, "Delete")
                    }
                }
            }
        }
    }
}

