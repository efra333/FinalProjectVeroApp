package com.example.veroshoppeapp

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import androidx.core.content.edit

object AppointmentStorageHelper {
    private const val PREFS_NAME = "appointments_prefs"
    private const val APPOINTMENTS_KEY = "appointments_list"

    fun saveAppointments(context: Context, appointments: List<Appointment>) {
        val json = Gson().toJson(appointments)
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit() {
                putString(APPOINTMENTS_KEY, json)
            }
    }

    fun getAppointments(context: Context): List<Appointment> {
        val json = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(APPOINTMENTS_KEY, null) ?: return emptyList()

        val type = object : TypeToken<List<Appointment>>() {}.type
        return Gson().fromJson(json, type) ?: emptyList()
    }

    fun deleteAppointment(context: Context, appointmentId: Int) {
        val appointments = getAppointments(context).toMutableList()
        appointments.removeAll { it.id == appointmentId }
        saveAppointments(context, appointments)
    }
}