package com.example.veroshoppeapp

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun HomeScreen(
    navController: NavController,
    onNavigateToProfile: () -> Unit) {
    var userName by remember { mutableStateOf("") }
    var zodiacSign by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }

    // Fetch user data from Firestore
    LaunchedEffect(Unit) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return@LaunchedEffect
        FirebaseFirestore.getInstance()
            .collection("users")
            .document(userId)
            .get()
            .addOnSuccessListener { document ->
                userName = document.getString("name") ?: ""
                zodiacSign = document.getString("zodiacSign") ?: ""
                isLoading = false
            }
            .addOnFailureListener {
                isLoading = false
            }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Main content
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator()
            } else {
                Text(
                    text = "Welcome, $userName!",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                Text(
                    text = "Your Zodiac Sign: $zodiacSign",
                    fontSize = 20.sp,
                    modifier = Modifier.padding(bottom = 24.dp)
                )

                // Example horoscope message based on zodiac sign
                val horoscopeMessage = when (zodiacSign) {
                    "Aries" -> "La fuerza estara contigo. ¡Hoy es un buen dia para tomar decisiones!"
                    else -> "¡Hoy es un gran dia para intentar un nuevo estilo de cabello!"
                }

                Text(
                    text = horoscopeMessage,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        // Bottom navigation
        BottomNavigationBar(
            navController = navController,
            onProfileClick = onNavigateToProfile
        )
    }
}
//Iniciamos componente de barra de navegacion
@Composable
fun BottomNavigationBar(
    navController: NavController,
    onProfileClick: () -> Unit
) {
    val items = listOf(
        BottomNavItem.Home,
        BottomNavItem.Appointments,
        BottomNavItem.Catalog
    )

    val currentRoute = navController.currentDestination?.route

    NavigationBar {
        items.forEach { item ->
            NavigationBarItem(
                icon = { Icon(item.icon, contentDescription = item.title) },
                label = { Text(item.title) },
                selected = currentRoute == item.route,
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                }
            )
        }

        // Custom handling for profile
        NavigationBarItem(
            icon = { Icon(BottomNavItem.Profile.icon, contentDescription = BottomNavItem.Profile.title) },
            label = { Text(BottomNavItem.Profile.title) },
            selected = false,
            onClick = { onProfileClick() }
        )
    }
}

// Update your BottomNavItem sealed class:
sealed class BottomNavItem(val route: String, val title: String, val icon: ImageVector) {
    object Home : BottomNavItem("home", "Home", Icons.Default.Home)
    object Appointments : BottomNavItem("appointments", "Appointments", Icons.Default.DateRange)
    object Catalog : BottomNavItem("catalog", "Catalog", Icons.Default.ShoppingCart)
    object Profile : BottomNavItem("profile", "Profile", Icons.Default.Person)
}