package com.example.veroshoppeapp

import java.util.UUID  // Only if you're using UUID for ID generation

data class CatalogItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String,
    val imageUri: String? = null // Will store URI as string
)
