package com.example.veroshoppeapp

data class Appointment(
    val id: Int = generateUniqueId(),
    val date: String,  // Format: "YYYY-MM-DD"
    val hour: String,  // Format: "HH:MM"
    val userEmail: String
) {
    companion object {
        private var lastId = 0
        fun generateUniqueId(): Int {
            return ++lastId
        }
    }
}
